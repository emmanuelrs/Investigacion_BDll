package servlets;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import paquete.Neo4j;

/**
 * Servlet implementation class Inicio
 */
@WebServlet("/Inicio")
public final class Inicio extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private BufferedReader br;
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Inicio() { super(); }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setCharacterEncoding("UTF-8");
		String correo  = request.getParameter("correo");
		String contrase�a = request.getParameter("pass");
		Neo4j neo4j = new Neo4j();
		if (neo4j.autentificar(correo, contrase�a)) {
			crearWeb(response, correo, neo4j.obtenerNodo(correo), neo4j.retonarSeguidores(correo)); } 
		else {
			imprimirWeb(response); } }
	
	private void crearWeb(HttpServletResponse response, String correo, ArrayList<String> info, ArrayList<String> seguidores) 
			throws IOException {
		escribir(correo);
		PrintWriter web = response.getWriter();
		web.println("<!DOCTYPE html><html><head><meta charset=\"utf-8\" /><meta http-equiv=\"X-UA-Compatible\" content=\"chrome=1\" /><meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, maximum-scale=1.0\"><title>Hi-C! - Perfil</title><link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro:400,700|Open+Sans:300italic,400,300,700' rel='stylesheet' type='text/css'><link rel=\"stylesheet\" type=\"text/css\" href=\"packaged/css/semantic.css\"><script src=\"http://cdnjs.cloudflare.com/ajax/libs/jquery/2.0.3/jquery.js\"></script><script src=\"http://cdnjs.cloudflare.com/ajax/libs/jquery.address/1.6/jquery.address.js\"></script><script src=\"packaged/javascript/semantic.js\"></script><style type=\"text/css\"> .centerDiv { width: 60%; margin: 0 auto; } </style></head>");
		web.println("<header><div class=\"ui pointing menu\"><form class=\"left menu\" action=\"profile\" method=\"post\">");
		web.println("<a class=\"active item\"> Bienvenido a Hi-C! [" + correo + "] </a>");
		web.println("<input type=\"hidden\" name=\"correo\" value=\"" + correo + "\" />");
		web.println("<input class=\"ui basic button\" type=\"submit\" value=\"Mi Perfil\" /><a class=\"ui basic button\" href=\"Inicio.html\">Cerrar Sesi�n</a></form><form class=\"right menu\" action=\"search\" method=\"post\"><div class=\"item\"><input class=\"ui action input\" type=\"text\" name=\"busca\"/></div><div class=\"item\"><input class=\"ui button\" type=\"submit\" value=\"Buscar\"/></div><div class=\"ui dropdown item\"> Lenguaje <i class=\"dropdown icon\"></i></div></form></div><div class=\"ui header\"><div class=\"ui inverted segment\"><h2 align=\"center\">Perfil</h2></div></div></header>");
		web.println("<body id=\"perfil\" style=\"background: lightblue;\"><div class=\"ui vertically divided grid\"><div class=\"two column row\"><div class=\"column\"><br></br><div class=\"centerDiv\"><div class=\"ui items\"><div class=\"item\"><div class=\"image\"><img src=\"https://imagizer.imageshack.us/v2/300x300q90/537/IOKM9e.png\"></img></div>-------------------------------------------");
		web.println("<form class=\"content\" action=\"follow\" method=\"post\"><input type=\"hidden\" name=\"correo1\" value=\"" + correo + "\" />");
		
		web.println("<input type=\"hidden\" name=\"correo2\" value=\"" + info.get(2) + "\" />");
		web.println("<input class=\"ui fluid active button\" type=\"submit\" value=\"Seguir\" /></form></div></div></div></div><div class=\"column\"><p></p><div class=\"ui piled segment\">");
		web.println("<div class=\"ui ribbon label\">Nombre</div><p>"+ info.get(0) +"</p>");
		web.println("<div class=\"ui ribbon label\">Apodo</div><p>" + info.get(1) +"</p>");
		web.println("<div class=\"ui ribbon label\">Correo Electr�nico</div><p>" + info.get(2) +"</p>");
		web.println("<div class=\"ui ribbon label\">Fecha de Nacimiento</div><p>"+ info.get(3) +"</p>");
		web.println("<div class=\"ui ribbon label\">Pa�s</div><p>" + info.get(4) + "</p>");
		web.println("</div></div></div><div class=\"one column row\"><div class=\"column\"><div class=\"ui segment\"><h4 class=\"ui inverted green block header\">Seguidores</h4><p><div class=\"ui selection list\">");
		// For
		int a=0; int b=1; int c=2; int d=3;
		if (!seguidores.isEmpty()) {
			while (a<seguidores.size()) {
				web.println("<form class=\"item\" action=\"profile\" method=\"post\"><img class=\"ui avatar image\" src=\"http://www.iconeasy.com/icon/thumbnails/System/Boomy/User%20Icon.jpg\">");
				web.println("<input type=\"hidden\" name=\"correo\" value=\"" + seguidores.get(b) + "\"/>");
				web.println("<div class=\"content\"><div class=\"header\">" + seguidores.get(c) + " " + seguidores.get(a) + "</div>(" + seguidores.get(d) + ")</div>");
				web.println("<input class=\"ui mini button\" type=\"submit\" value=\"ver perfil\"/></form>");
				a+=4; b+=4; c+=4; d+=4; } }
		
		web.println("</div></div></div></div></div></body></html>"); }
	
	private void escribir(String correo) throws IOException{
		PrintWriter writer = new PrintWriter("C:/Users/Xavier/workspace/Hi-C/WebContent/Perfil.html", "UTF-8");
		writer.println("<!DOCTYPE html><html><head><meta charset=\"utf-8\" /><meta http-equiv=\"X-UA-Compatible\" content=\"chrome=1\" /><meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, maximum-scale=1.0\"><title>Hi-C! - Perfil</title><link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro:400,700|Open+Sans:300italic,400,300,700' rel='stylesheet' type='text/css'><link rel=\"stylesheet\" type=\"text/css\" href=\"packaged/css/semantic.css\"><script src=\"http://cdnjs.cloudflare.com/ajax/libs/jquery/2.0.3/jquery.js\"></script><script src=\"http://cdnjs.cloudflare.com/ajax/libs/jquery.address/1.6/jquery.address.js\"></script><script src=\"packaged/javascript/semantic.js\"></script><style type=\"text/css\"> .centerDiv { width: 60%; margin: 0 auto; } </style></head>");
		writer.println("<header><div class=\"ui pointing menu\"><form class=\"left menu\" action=\"profile\" method=\"post\">");
		writer.println("<a class=\"active item\"> Bienvenido a Hi-C! [" + correo + "] </a>");
		writer.println("<input type=\"hidden\" name=\"correo\" value=\"" + correo + "\" />");
		writer.println("<input class=\"ui basic button\" type=\"submit\" value=\"Mi Perfil\" /><a class=\"ui basic button\" href=\"Inicio.html\">Cerrar Sesi�n</a></form><form class=\"right menu\" action=\"search\" method=\"post\"><div class=\"item\"><input class=\"ui action input\" type=\"text\" name=\"busca\"/></div><div class=\"item\"><input class=\"ui button\" type=\"submit\" value=\"Buscar\"/></div><div class=\"ui dropdown item\"> Lenguaje <i class=\"dropdown icon\"></i></div></form></div><div class=\"ui header\"><div class=\"ui inverted segment\"><h2 align=\"center\">Perfil</h2></div></div></header>");
		writer.println("<body id=\"perfil\" style=\"background: lightblue;\"><div class=\"ui vertically divided grid\"><div class=\"two column row\"><div class=\"column\"><br></br><div class=\"centerDiv\"><div class=\"ui items\"><div class=\"item\"><div class=\"image\"><img src=\"https://imagizer.imageshack.us/v2/300x300q90/537/IOKM9e.png\"></img></div>-------------------------------------------");
		writer.println("<form class=\"content\" action=\"follow\" method=\"post\"><input type=\"hidden\" name=\"correo1\" value=\"" + correo + "\" />");
		writer.close(); 
		
		writer = new PrintWriter("C:/Users/Xavier/workspace/Hi-C/WebContent/Busqueda.html", "UTF-8");
		writer.println("<!DOCTYPE html><html><head><meta charset=\"utf-8\" /><meta http-equiv=\"X-UA-Compatible\" content=\"chrome=1\" /><meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, maximum-scale=1.0\"><title>Hi-C! - B�squeda</title><link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro:400,700|Open+Sans:300italic,400,300,700' rel='stylesheet' type='text/css'><link rel=\"stylesheet\" type=\"text/css\" href=\"packaged/css/semantic.css\"><script src=\"http://cdnjs.cloudflare.com/ajax/libs/jquery/2.0.3/jquery.js\"></script><script src=\"http://cdnjs.cloudflare.com/ajax/libs/jquery.address/1.6/jquery.address.js\"></script><script src=\"packaged/javascript/semantic.js\"></script><style type=\"text/css\"> .centerDiv { width: 60%; margin: 0 auto; } </style></head>");
		writer.println("<header><div class=\"ui pointing menu\"><form class=\"left menu\" action=\"profile\" method=\"post\">");
		writer.println("<a class=\"active item\"> Bienvenido a Hi-C! [" + correo + "] </a>");
		writer.println("<input type=\"hidden\" name=\"correo\" value=\"" + correo + "\" />");
		writer.println("<input class=\"ui basic button\" type=\"submit\" value=\"Mi Perfil\" /><a class=\"ui basic button\" href=\"Inicio.html\">Cerrar Sesi�n</a></form><form class=\"right menu\" action=\"search\" method=\"post\"><div class=\"item\"><input class=\"ui action input\" type=\"text\" name=\"busca\"/></div><div class=\"item\"><input class=\"ui button\" type=\"submit\" value=\"Buscar\"/></div><div class=\"ui dropdown item\"> Lenguaje <i class=\"dropdown icon\"></i></div></form></div><div class=\"ui header\"><div class=\"ui inverted segment\"><h2 align=\"center\">B�squeda</h2></div></div></header>");
		writer.close(); }
	
	private void imprimirWeb(HttpServletResponse response) throws IOException {
		PrintWriter salida = response.getWriter();
		br = new BufferedReader(new FileReader("C:/Users/Xavier/workspace/Hi-C/WebContent/InicioError.html"));
		String l�nea = null;
		while ((l�nea = br.readLine()) != null) { salida.println(l�nea); } }
}