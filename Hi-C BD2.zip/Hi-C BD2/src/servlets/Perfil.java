package servlets;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import paquete.Neo4j;

/**
 * Servlet implementation class Perfil
 */
@WebServlet("/Perfil")
public final class Perfil extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private BufferedReader br;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Perfil() { super(); }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setCharacterEncoding("UTF-8");
		String correo = request.getParameter("correo");
		Neo4j neo4j = new Neo4j();
		crearWeb(response, neo4j.obtenerNodo(correo), neo4j.retonarSeguidores(correo)); }
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setCharacterEncoding("UTF-8");
		String correo = request.getParameter("correo");
		Neo4j neo4j = new Neo4j();
		crearWeb(response, neo4j.obtenerNodo(correo), neo4j.retonarSeguidores(correo)); }
	
	private void crearWeb(HttpServletResponse response, ArrayList<String> info, ArrayList<String> seguidores) throws IOException {
		PrintWriter salida = response.getWriter();
		br = new BufferedReader(new FileReader("C:/Users/Xavier/workspace/Hi-C/WebContent/Perfil.html"));
		String l�nea = null;
		while ((l�nea = br.readLine()) != null) { salida.println(l�nea); }
		
		salida.println("<input type=\"hidden\" name=\"correo2\" value=\"" + info.get(2) + "\" />");
		salida.println("<input class=\"ui fluid active button\" type=\"submit\" value=\"Seguir\" /></form></div></div></div></div><div class=\"column\"><p></p><div class=\"ui piled segment\">");
		salida.println("<div class=\"ui ribbon label\">Nombre</div><p>"+ info.get(0) +"</p>");
		salida.println("<div class=\"ui ribbon label\">Apodo</div><p>" + info.get(1) +"</p>");
		salida.println("<div class=\"ui ribbon label\">Correo Electr�nico</div><p>" + info.get(2) +"</p>");
		salida.println("<div class=\"ui ribbon label\">Fecha de Nacimiento</div><p>"+ info.get(3) +"</p>");
		salida.println("<div class=\"ui ribbon label\">Pa�s</div><p>" + info.get(4) + "</p>");
		salida.println("</div></div></div><div class=\"one column row\"><div class=\"column\"><div class=\"ui segment\"><h4 class=\"ui inverted green block header\">Seguidores</h4><p><div class=\"ui selection list\">");

		int a=0; int b=1; int c=2; int d=3;
		if (!seguidores.isEmpty()) {
			while (a<seguidores.size()) {
				salida.println("<form class=\"item\" action=\"profile\" method=\"post\"><img class=\"ui avatar image\" src=\"http://www.iconeasy.com/icon/thumbnails/System/Boomy/User%20Icon.jpg\">");
				salida.println("<input type=\"hidden\" name=\"correo\" value=\"" + seguidores.get(b) + "\"/>");
				salida.println("<div class=\"content\"><div class=\"header\">" + seguidores.get(c) + " " + seguidores.get(a) + "</div>(" + seguidores.get(d) + ")</div>");
				salida.println("<input class=\"ui mini button\" type=\"submit\" value=\"ver perfil\"/></form>");
				a+=4; b+=4; c+=4; d+=4; } }
		
		salida.println("</div></div></div></div></div></body></html>"); }
}
