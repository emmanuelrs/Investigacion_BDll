package servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import paquete.Neo4j;

/**
 * Servlet implementation class Registro
 */
@WebServlet("/Registro")
public final class Registro extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Registro() { super(); }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setCharacterEncoding("UTF-8");
		String contextPath = request.getContextPath();
		
		String nombre = request.getParameter("nombre");
		String apellidos = request.getParameter("apellidos");
		String apodo = request.getParameter("apodo");
		String correo = request.getParameter("correo");
		String contrase�a = request.getParameter("pass");
		String fecha = request.getParameter("fecha");
		String pa�s = request.getParameter("pais");
		Neo4j neo4j = new Neo4j();
		neo4j.a�adirNodo(nombre, apodo, apellidos, correo, contrase�a, fecha, pa�s);
		
		response.sendRedirect(response.encodeRedirectURL(contextPath + "/Inicio.html")); }

}
