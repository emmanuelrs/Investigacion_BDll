package servlets;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import paquete.Neo4j;

/**
 * Servlet implementation class B�squeda
 */
@WebServlet("/B�squeda")
public final class B�squeda extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private BufferedReader br;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public B�squeda() { super(); }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setCharacterEncoding("UTF-8");
		String correo = request.getParameter("busca");
		Neo4j neo4j = new Neo4j();
		crearWeb(response, neo4j.obtenerNodo(correo)); }
	
	private void crearWeb(HttpServletResponse response, ArrayList<String> info) throws IOException {
		PrintWriter salida = response.getWriter();
		br = new BufferedReader(new FileReader("C:/Users/Xavier/workspace/Hi-C/WebContent/Busqueda.html"));
		String l�nea = null;
		while ((l�nea = br.readLine()) != null) { salida.println(l�nea); }
		
		salida.println("<body id=\"b�squeda\" style=\"background: lightblue;\"><div class=\"ui segment\"><div class=\"ui selection list\"><h4 class=\"ui inverted green block header\">Resultados</h4><p><form class=\"item\" action=\"profile\" method=\"post\"><img class=\"ui avatar image\" src=\"http://www.iconeasy.com/icon/thumbnails/System/Boomy/User%20Icon.jpg\">");
		if (!info.isEmpty()){
			salida.println("<input type=\"hidden\" name=\"correo\" value=\"" + info.get(2) + "\"/>");
			salida.println("<div class=\"content\"><div class=\"header\">" + info.get(0) + "</div>(" + info.get(1) + ")</div>");
			salida.println("<input class=\"ui mini button\" type=\"submit\" value=\"ver perfil\"/>"); }
		salida.println("</form></div></div></body></html>"); }
}
