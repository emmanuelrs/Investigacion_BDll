package paquete;

import java.util.ArrayList;


public abstract class Principal {

	public Principal() { }

	public static void main(String[] args) {
		Neo4j neo4j = new Neo4j();
		//neo4j.a�adirNodo("Jos�", "Chepe", "Castro", "jcastro@itcr.ac.cr", "12345", "06/06/6666", "Costa Rica");
		//neo4j.a�adirNodo("Xavier", "Xavi", "Vega", "xvega@itcr.ac.cr", "12345", "06/06/6666", "Costa Rica");
		//neo4j.a�adirNodo("V�ctor", "Victillor", "Saborio", "vsaborio@itcr.ac.cr", "12345", "06/06/6666", "Costa Rica");
		//neo4j.a�adirNodo("Pablo", "Luchis", "Baltodano", "pbaltodano@itcr.ac.cr", "12345", "06/06/6666", "Costa Rica");
		//neo4j.a�adirNodo("William", "Willy", "Rojas", "wrojas@itcr.ac.cr", "12345", "06/06/6666", "Costa Rica");
		//neo4j.a�adirNodo("Jos� E.", "Morfeo", "Araya", "jaraya@itcr.ac.cr", "12345", "06/06/6666", "Costa Rica");
		//neo4j.a�adirNodo("Christian", "cherif", "Carvajal", "ccarvajal@itcr.ac.cr", "12345", "06/06/6666", "Costa Rica");
		//neo4j.relacionar("ccarvajal@itcr.ac.cr", "jcastro@itcr.ac.cr");
		//neo4j.relacionar("xvega@itcr.ac.cr", "jcastro@itcr.ac.cr");
		//neo4j.relacionar("vsaborio@itcr.ac.cr", "jcastro@itcr.ac.cr");
		//neo4j.relacionar("pbaltodano@itcr.ac.cr", "jcastro@itcr.ac.cr");
		ArrayList<String> lista = neo4j.retonarSeguidores("jcastro@itcr.ac.cr");
		System.out.println(lista.toString()); 
		} }